from setuptools import setup, find_packages

setup(
    name="notem-mcp",
    version="0.4.0",
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'notem-mcp = notem_mcp.main:start_server',
        ],
    },
)
